import importlib.util, sys, types, pathlib

def run_candidate(code_str: str, test_file: str):
    # Execute candidate code in its own namespace
    ns = {}
    exec(code_str, ns, ns)
    # Load the test module and call run_tests(ns)
    spec = importlib.util.spec_from_file_location("testmod", test_file)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore
    total = mod.run_tests(ns)
    return total

if __name__ == "__main__":
    # Example usage:
    # python run_tests.py data/tests/add_fix_test.py "def add(a,b):\n    return a+b\n"
    test_file = sys.argv[1]
    code_str = sys.argv[2]
    passed = run_candidate(code_str, test_file)
    print(passed)
