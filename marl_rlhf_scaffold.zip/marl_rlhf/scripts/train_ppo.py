import argparse, json, os, pathlib, random, subprocess, sys, tempfile
from dataclasses import dataclass
from typing import List, Dict, Any

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from trl import PPOTrainer, PPOConfig, AutoModelForCausalLMWithValueHead

BASE = pathlib.Path(__file__).resolve().parents[1]
DATA_PATH = BASE / "data" / "pairs.jsonl"
TESTS_DIR = BASE / "data" / "tests"
JUDGE_RUNNER = BASE / "judge" / "run_tests.py"

def load_pairs(path: pathlib.Path) -> List[Dict[str, Any]]:
    pairs = []
    with open(path, "r") as f:
        for line in f:
            pairs.append(json.loads(line))
    return pairs

def run_unit_tests(code_str: str, test_file: pathlib.Path) -> int:
    """Return number of assertions passed (integer)."""
    # We call the bundled runner as a subprocess to sandbox a bit.
    out = subprocess.check_output(
        [sys.executable, str(JUDGE_RUNNER), str(test_file), code_str],
        stderr=subprocess.STDOUT,
        text=True,
    )
    try:
        return int(out.strip())
    except Exception:
        return 0

def format_prompt(p: Dict[str, Any]) -> str:
    return p["prompt"].strip() + "\n\n# Please provide ONLY the corrected function."

def generate_candidates(model, tokenizer, prompts: List[str], max_new_tokens: int, do_sample: bool=True, temperature: float=0.7):
    inputs = tokenizer(prompts, return_tensors="pt", padding=True).to(model.device)
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=do_sample,
            temperature=temperature,
            pad_token_id=tokenizer.eos_token_id,
        )
    texts = tokenizer.batch_decode(outputs, skip_special_tokens=True)
    # Strip original prompt to get only the completion tail
    completions = []
    for i, t in enumerate(texts):
        pref = prompts[i]
        if t.startswith(pref):
            completions.append(t[len(pref):].strip())
        else:
            # Fallback: take the last block after the prompt
            completions.append(t.splitlines()[-max(1, min(30, t.count('\n'))):])
            completions[-1] = t[len(t)-len(completions[-1]):].strip() if isinstance(completions[-1], str) else t.strip()
    return completions

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, required=True, help="HF model id or local path")
    parser.add_argument("--save_dir", type=str, default=str(BASE / "checkpoints"))
    parser.add_argument("--load_4bit", type=str, default="false")
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--per_device_batch_size", type=int, default=1)
    parser.add_argument("--max_new_tokens", type=int, default=64)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    random.seed(args.seed)

    load_in_4bit = args.load_4bit.lower() == "true"
    tokenizer = AutoTokenizer.from_pretrained(args.model, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # Load LM with value head for PPO
    base_kwargs = {}
    if load_in_4bit:
        base_kwargs.update(dict(load_in_4bit=True))
    policy = AutoModelForCausalLMWithValueHead.from_pretrained(args.model, **base_kwargs)
    policy = policy.to("cuda" if torch.cuda.is_available() else "cpu")

    # Small PPO config
    ppo_config = PPOConfig(
        model_name=args.model,
        learning_rate=1e-6 if load_in_4bit else 1e-5,
        ppo_epochs=2,
        mini_batch_size=args.per_device_batch_size,
        batch_size=args.per_device_batch_size,
        gradient_accumulation_steps=1,
        remove_unused_columns=False,
        init_kl_coef=0.05,
        target_kl=0.1,
    )
    ppo_trainer = PPOTrainer(ppo_config, policy, ref_model=None, tokenizer=tokenizer)

    pairs = load_pairs(DATA_PATH)
    os.makedirs(args.save_dir, exist_ok=True)

    for epoch in range(args.epochs):
        print(f"\n=== Epoch {epoch+1}/{args.epochs} ===")
        random.shuffle(pairs)
        texts = []
        queries = []
        rewards = []

        for ex in pairs:
            prompt = format_prompt(ex)
            # Generate TWO candidates for a pairwise comparison
            cand_a = generate_candidates(policy.pretrained_model, tokenizer, [prompt], args.max_new_tokens)[0]
            cand_b = generate_candidates(policy.pretrained_model, tokenizer, [prompt], args.max_new_tokens)[0]

            # Score by running tests
            test_file = TESTS_DIR / f"{ex['id']}_test.py"
            score_a = run_unit_tests(cand_a, test_file)
            score_b = run_unit_tests(cand_b, test_file)

            # Define scalar rewards from scores (normalize to [0,1] by max tests in that file)
            max_tests = 3  # each test file in the toy set has 3 asserts
            ra = score_a / max_tests
            rb = score_b / max_tests

            # Pick the better response as "preferred"
            if ra >= rb:
                chosen, r = cand_a, ra
            else:
                chosen, r = cand_b, rb

            queries.append(prompt)
            texts.append(chosen)
            rewards.append(r)

            print(f"{ex['id']}: scores A={score_a}, B={score_b} -> reward={r:.2f}")

        # Tokenize for PPO
        tokenized_queries = tokenizer(queries, return_tensors="pt", padding=True).to(policy.device)
        tokenized_responses = tokenizer(texts, return_tensors="pt", padding=True).to(policy.device)

        # PPO expects lists of strings for queries/responses; rewards as tensors
        # We'll step per-sample to keep it simple and VRAM-friendly.
        for q, r_text, r_scalar in zip(queries, texts, rewards):
            q_toks = tokenizer(q, return_tensors="pt").to(policy.device)
            # Generate again to get logprobs/values tracked by PPO (teacher-forcing the chosen text)
            # For simplicity, we treat the chosen text as the response the agent produced.
            # PPOTrainer.step expects lists
            r = torch.tensor([r_scalar], dtype=torch.float32, device=policy.device)
            ppo_trainer.step([q], [r_text], r)

        # Save checkpoint each epoch
        save_path = pathlib.Path(args.save_dir) / f"epoch_{epoch+1}"
        ppo_trainer.model.pretrained_model.save_pretrained(save_path)
        tokenizer.save_pretrained(save_path)
        print(f"Saved checkpoint to {save_path}")

if __name__ == "__main__":
    main()
