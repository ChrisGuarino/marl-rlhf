import argparse, json, pathlib, subprocess, sys
from typing import Dict, Any, List

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

BASE = pathlib.Path(__file__).resolve().parents[1]
DATA_PATH = BASE / "data" / "pairs.jsonl"
TESTS_DIR = BASE / "data" / "tests"
JUDGE_RUNNER = BASE / "judge" / "run_tests.py"

def load_pairs(path: pathlib.Path) -> List[Dict[str, Any]]:
    pairs = []
    with open(path, "r") as f:
        for line in f:
            pairs.append(json.loads(line))
    return pairs

def run_unit_tests(code_str: str, test_file: pathlib.Path) -> int:
    out = subprocess.check_output(
        [sys.executable, str(JUDGE_RUNNER), str(test_file), code_str],
        stderr=subprocess.STDOUT,
        text=True,
    )
    try:
        return int(out.strip())
    except Exception:
        return 0

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, required=True, help="HF model id or local path")
    parser.add_argument("--max_new_tokens", type=int, default=64)
    args = parser.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    tok = AutoTokenizer.from_pretrained(args.model, use_fast=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(args.model).to(device)

    pairs = load_pairs(DATA_PATH)
    total_tests = 0
    total_passed = 0

    for ex in pairs:
        prompt = ex["prompt"].strip() + "\n\n# Please provide ONLY the corrected function."
        inputs = tok(prompt, return_tensors="pt").to(device)
        with torch.no_grad():
            out = model.generate(
                **inputs,
                max_new_tokens=args.max_new_tokens,
                do_sample=False,
                pad_token_id=tok.eos_token_id,
            )
        text = tok.decode(out[0], skip_special_tokens=True)
        completion = text[len(prompt):].strip() if text.startswith(prompt) else text

        passed = run_unit_tests(completion, TESTS_DIR / f"{ex['id']}_test.py")
        print(f"{ex['id']}: passed {passed}/3")
        total_tests += 3
        total_passed += passed

    print(f"TOTAL: {total_passed}/{total_tests} ({100.0*total_passed/total_tests:.1f}% pass rate)")

if __name__ == "__main__":
    main()
