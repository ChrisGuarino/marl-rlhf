# MARL-RLHF Toy Project (PPO + Verifiable Rewards)

This repo is a **minimal scaffold** to train a small language model with RL (PPO) using
**verifiable rewards** from unit tests (a proxy for "judge" preferences).

## Contents
- `data/pairs.jsonl` — 5 toy preference examples
- `data/tests/*_test.py` — unit tests for each task
- `judge/run_tests.py` — executes a code candidate string against a test file
- `scripts/train_ppo.py` — PPO training stub using TRL (Hugging Face)
- `scripts/eval.py` — simple evaluation to compute pass rates over the dataset

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install "transformers>=4.41" "trl>=0.9" accelerate datasets peft bitsandbytes
```

> If you have a GPU and want 4-bit loading, ensure `bitsandbytes` installs correctly.
> Otherwise, set `--load_4bit false` on `train_ppo.py`.

## Quick Start (dry run / single epoch)

```bash
python scripts/train_ppo.py   --model mistralai/Mistral-7B-Instruct-v0.2   --load_4bit true   --epochs 1   --per_device_batch_size 1   --max_new_tokens 64
```

The script:
- loads prompts from `data/pairs.jsonl`
- generates **two** candidate fixes per prompt
- runs unit tests to compute verifiable scores
- converts the scores into scalar rewards
- performs a small PPO step

> Tip: For CPU-only or small VRAM, try a tiny model like `HuggingFaceTB/SmolLM2-360M-Instruct`
> and set `--load_4bit false`.

## Evaluate

```bash
python scripts/eval.py --model path/to/saved_or_pretrained --max_new_tokens 64
```

This will generate one candidate per prompt, run tests, and print the pass rate.

